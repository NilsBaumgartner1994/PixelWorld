package com.gentlemenssoftware.easyServer;

public enum EasyServerCommunicationTyp {
	
		HOST, CLIENT

}